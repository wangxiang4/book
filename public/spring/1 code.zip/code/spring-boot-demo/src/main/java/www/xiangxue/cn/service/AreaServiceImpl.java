package www.xiangxue.cn.service;

import cn.enjoy.annotation.EasyCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import www.xiangxue.cn.dao.CommonMapper;
import www.xiangxue.cn.pojo.ConsultConfigArea;

import java.util.List;

@Service
public class AreaServiceImpl implements AreaService {

    @Autowired
    private CommonMapper commonMapper;

    @EasyCache(key = "#areaCode")
    @Override
    public List<ConsultConfigArea> queryAreaFromDB(String areaCode) {
        List<ConsultConfigArea> areas = commonMapper.queryAreaByAreaCode(areaCode);
        return areas;
    }
}
