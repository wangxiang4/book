package www.xiangxue.cn.service;


import www.xiangxue.cn.pojo.ConsultConfigArea;

import java.util.List;

public interface AreaService {
    List<ConsultConfigArea> queryAreaFromDB(String areaCode);
}
