package www.xiangxue.cn;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;

/**
 * @Classname DemoApplication
 * @Description TODO
 * @Author Jack
 * Date 2020/12/3 13:52
 * Version 1.0
 */
@SpringBootApplication(exclude = RedisAutoConfiguration.class)
@MapperScan(basePackages = {"www.xiangxue.cn.dao"})
public class DemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class,args);
    }
}
