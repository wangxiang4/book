package www.xiangxue.cn.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import www.xiangxue.cn.DemoApplication;
import www.xiangxue.cn.pojo.ConsultConfigArea;
import www.xiangxue.cn.service.AreaService;

import java.util.List;

/**
 * @Classname MyTest
 * @Description TODO
 * @Author Jack
 * Date 2020/11/27 14:47
 * Version 1.0
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = DemoApplication.class)
public class MyTest {

    @Autowired
    private AreaService areaService;
    @Test
    public void test1() {
        List<ConsultConfigArea> cq12 = areaService.queryAreaFromDB("CQ12");
        System.out.println(cq12);
    }
}
