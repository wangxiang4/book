package www.xiangxue.com.service;


import www.xiangxue.com.pojo.ConsultConfigArea;

import java.util.List;

public interface AreaService {
    List<ConsultConfigArea> queryAreaFromDB(String areaCode);
}
