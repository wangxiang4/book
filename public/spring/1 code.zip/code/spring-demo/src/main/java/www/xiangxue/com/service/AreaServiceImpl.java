package www.xiangxue.com.service;

import cn.enjoy.annotation.EasyCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import www.xiangxue.com.dao.CommonMapper;
import www.xiangxue.com.pojo.ConsultConfigArea;

import java.util.List;

@Service
public class AreaServiceImpl implements AreaService {

    @Autowired
    private CommonMapper commonMapper;

    @EasyCache(key = "#areaCode")
    @Override
    public List<ConsultConfigArea> queryAreaFromDB(String areaCode) {
        List<ConsultConfigArea> areas = commonMapper.queryAreaByAreaCode(areaCode);
        return areas;
    }
}
