package www.xiangxue.com;

import cn.enjoy.cache.CacheAutoconfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * @Classname CacheConfig
 * @Description TODO
 * @Author Jack
 * Date 2020/12/2 18:00
 * Version 1.0
 */
@Configuration
@Import(CacheAutoconfig.class)
public class CacheConfig {
}
