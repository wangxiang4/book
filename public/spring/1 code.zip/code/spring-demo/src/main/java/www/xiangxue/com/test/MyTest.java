package www.xiangxue.com.test;

import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import www.xiangxue.com.pojo.ConsultConfigArea;
import www.xiangxue.com.service.AreaService;

import java.util.List;

/**
 * @Classname MyTest
 * @Description TODO
 * @Author Jack
 * Date 2020/11/27 14:47
 * Version 1.0
 */
public class MyTest {

    @Test
    public void test1() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext("www.xiangxue.com");
        AreaService bean = applicationContext.getBean(AreaService.class);
        System.out.println(bean);

        List<ConsultConfigArea> cq12 = bean.queryAreaFromDB("CQ12");
        System.out.println(cq12);
    }
}
