package com.enjoy.entity;

public class A {
    boolean f;
}
