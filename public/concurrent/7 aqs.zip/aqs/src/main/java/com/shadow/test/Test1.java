package com.shadow.test;

import lombok.extern.slf4j.Slf4j;
import org.openjdk.jol.info.ClassLayout;
import sun.misc.Unsafe;

import java.util.HashMap;
import java.util.concurrent.locks.LockSupport;
import java.util.concurrent.locks.ReentrantLock;


/**
 * 1、什么是对象头？
 *  什么是对象？内存级别而言来研究什么是对象
 */

@Slf4j(topic = "enjoy")
public class Test1 {
    static boolean isPrettyGril = false;
    static  Object key = new Object();


    /**
     * 多线程情况下 假设某个线程拿到锁了，但是他需要满足某个条件
     * 才能执行 如果用sleep 会导致在没有满足条件的情况下；我一直阻塞
     * 一直持有锁，别的线程也拿不到锁
     * 得有办公室的key
     * boss 需要叫jack 去加班编程；还有其他十个人是自愿加班
     * jack不愿加班---你给我女人
     * @param args
     * @throws InterruptedException
     */

    public static   void main(String[] args) throws InterruptedException {
        //jack
        new Thread(() -> {
            synchronized (key) {
                log.debug("有没有女人[{}]", isPrettyGril);
                if (!isPrettyGril) {
                    log.debug("没有女人！等女人，等5秒;别人也不能干活");
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                log.debug("等了5秒 有没有女人？[{}]", isPrettyGril);
                if (isPrettyGril) {
                    log.debug("------男女搭配干活不累；啪啪啪写完了代码");
                }else{
                    log.debug("------下班回家----");
                }
            }
        }, "jack").start();




        for (int i = 0; i < 10; i++) {
            new Thread(() -> {
                    synchronized (key) {
                        log.debug("我们10个屌丝工作了");
                    }
                }, "其它人").start();
        }


        Thread.sleep(1000);
        new Thread(() -> {
            synchronized (key) {
                isPrettyGril = true;
                log.debug("桥本有菜来了");
            }
        }, "boss").start();

    }


   public synchronized  void aa(){

   }

    public   void cc(){
        Class<Test1> test1Class = Test1.class;
        synchronized (this){

        }
    }


}
